export const imagesPath = {
	logo: {
		path: '/logo.svg'
	},

}