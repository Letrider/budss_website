import { useMemo, useState } from 'react';
import Header from './components/Header/Header';
import Tabs from './components/Tabs/Tabs';
import { TabsConfigs } from './configs/Tabs.config';
import { FirstSection } from './components/Main/FirstSection';
import { SecondSection } from './components/Main/SecondSection';
import { Cookie } from './components/Cookie/Cookie';
import { ThirdSection } from './components/Main/ThirdSection';
import { BannerSection } from './components/Main/BannerSection';

function App() {
     const [activeTab, setActiveTab] = useState(TabsConfigs.Business);
     const [showCookie, setShowCookie] = useState(false);

     return (
          <div className="budss">
               <Tabs currentTab={activeTab} setCurrentTab={setActiveTab} />
               <Header />
               <FirstSection />
               <SecondSection />
               <ThirdSection />
               <BannerSection />
               {showCookie && <Cookie setShow={setShowCookie} />}
          </div>
     );
}

export default App;
