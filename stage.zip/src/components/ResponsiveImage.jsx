const ResponsiveImage = ({ srcWebp, srcDefault, alt, className }) => {
     return (
          <picture className={className}>
               <source srcSet={srcWebp} type="image/webp" />
               <img src={srcDefault} alt={alt} />
          </picture>
     );
};

export default ResponsiveImage;
