import { useState } from 'react';
import cn from './Button.module.scss';

export const Button = ({
     label,
     icon,
     size,
     disabled,
     type = 'Primary',
     onClick,
}) => {
     const buttonClasses = [
          cn.button,
          size === 'large' && cn['button--large'],
          disabled && cn['button--disabled'],
          type === 'Primary' ? cn['button--primary'] : cn['button--secondary'],
     ]
          .filter(Boolean)
          .join(' ');

     const [loading, setLoading] = useState(false);

     return (
          <button
               className={buttonClasses}
               onClick={onClick}
               // onClick={() => {
               //      setLoading(true);
               //      setTimeout(() => {
               //           setLoading(false);
               //      }, 2000);
               // }}
               disabled={disabled}
          >
               {icon && <span className={cn['button__icon']}>{icon}</span>}
               {loading && (
                    <img
                         src="/loading.svg"
                         className={cn['button--loading']}
                         alt="loading"
                    />
               )}
               {!loading ? label : null}
          </button>
     );
};
