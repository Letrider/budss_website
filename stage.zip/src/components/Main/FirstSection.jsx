import { Button } from '../Button/Button';
import ResponsiveImage from '../ResponsiveImage';
import cn from './FirstSection.module.scss';

export const FirstSection = () => {
     return (
          <section className={cn['section-1']}>
               <div className={cn['section-1__left']}>
                    <h1>
                         Everyone <br /> is an Influencer
                    </h1>
                    <p>
                         Budss is a payments as a service and WOM engine
                         dedicated
                         <br /> to acquisition and retention of customers to
                         your business.
                    </p>
                    <Button label={'Contact sales'} />
               </div>
               <div className={cn['section-1__right']}>
                    <ResponsiveImage
                         className={cn['section-1__right-woman']}
                         srcDefault={'/woman.png'}
                    />
               </div>
          </section>
     );
};
