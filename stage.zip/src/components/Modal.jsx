import { useState } from 'react';
import InputMask from 'react-input-mask';

const Modal = ({ isOpen, onClose }) => {
     const [phone, setPhone] = useState('');

     const handleSubmit = (e) => {
          e.preventDefault();
          console.log('Телефон:', phone);
     };

     if (!isOpen) return null;

     return (
          <div className="modal">
               <form className="modal__form" onSubmit={handleSubmit}>
                    <label>
                         Телефон*:
                         <InputMask
                              mask="+7 (999) 999-99-99"
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                              required
                         />
                    </label>
                    <button type="submit">Отправить</button>
               </form>
               <button onClick={onClose} className="modal__close">
                    Закрыть
               </button>
          </div>
     );
};

export default Modal;
