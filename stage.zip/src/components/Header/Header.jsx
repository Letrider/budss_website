import ResponsiveImage from '../ResponsiveImage';
import cn from './Header.module.scss';
import { imagesPath } from '../../configs/Images.config';
import { Button } from '../../components/Button/Button';

const Header = () => {
     return (
          <header className={cn.header}>
               <div className={cn['header-container']}>
                    <ResponsiveImage
                         srcWebp
                         srcDefault={imagesPath.logo.path}
                    />
                    <p className={cn['header-container__subtitle']}>budss</p>
               </div>

               <Button label={'Contact sales'} />
          </header>
     );
};

export default Header;
