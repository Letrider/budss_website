export const TRANSITION = {
	logo: 0.25,
	button: 0.25,
	title: (i) => (i + 1) / 10,
	paragraph: 0.5,
	womanImage: 0.5,
}