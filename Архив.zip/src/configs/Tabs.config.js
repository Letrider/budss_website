export const TabsConfigs = {
	'Business': 'For Business',
	'Customers': 'For Customers',
}