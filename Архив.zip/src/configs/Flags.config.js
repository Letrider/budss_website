export const countryFlags = {
	'+1': '/flags/united-states-of-america.svg',
	'+7': '/flags/russian-federation.svg',
}